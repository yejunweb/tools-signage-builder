import { type GenerateSignCanvasInput, canvasToDataUrl, generateSignCanvas } from './generateSignCanvas';

export const buildExportDataUrl = (input: GenerateSignCanvasInput): string => canvasToDataUrl(generateSignCanvas(input));

/** 浏览器 / Tauri webview 另存为 PNG */
export const downloadPng = (dataUrl: string, fileName: string) => {
    const safeName = fileName.endsWith('.png') ? fileName : `${fileName}.png`;
    const anchor = document.createElement('a');
    anchor.href = dataUrl;
    anchor.download = safeName;
    anchor.rel = 'noopener';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
};

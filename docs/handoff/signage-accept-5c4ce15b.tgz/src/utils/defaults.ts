import {
    ALL_SHOW_TYPES,
    DEFAULT_BACKGROUND,
    DEFAULT_BORDER_RADIUS,
    DEFAULT_HEIGHT,
    DEFAULT_WIDTH,
    defaultTextStyle,
} from '@/constants/signage';
import type { ShowInfoItem, SignDraft, SignRecord } from '@/types/signage';

import { createDefaultRecordName } from './format';
import { createId } from './id';

export const createEmptyRoom = (): ShowInfoItem => ({
    id: createId(),
    unitNum: '',
    roomId: '',
    area: '',
    unitStyle: defaultTextStyle(),
    roomStyle: defaultTextStyle(),
    areaStyle: defaultTextStyle(),
});

/** 新建进编辑的产品默认 */
export const createNewDraft = (): SignDraft => ({
    name: createDefaultRecordName(),
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,
    borderRadius: DEFAULT_BORDER_RADIUS,
    background: DEFAULT_BACKGROUND,
    transparentBackground: true,
    buildingNum: '',
    totalFloorNum: '',
    buildingStyle: defaultTextStyle(),
    floorStyle: defaultTextStyle(),
    showTypes: [...ALL_SHOW_TYPES],
    showInfoLs: [],
});

export const recordToDraft = (record: SignRecord): SignDraft => ({
    id: record.id,
    name: record.name,
    width: record.width,
    height: record.height,
    borderRadius: record.borderRadius,
    background: record.background,
    transparentBackground: record.transparentBackground,
    buildingNum: record.buildingNum,
    totalFloorNum: record.totalFloorNum,
    buildingStyle: { ...record.buildingStyle },
    floorStyle: { ...record.floorStyle },
    showTypes: [...record.showTypes],
    showInfoLs: record.showInfoLs.map(item => ({
        ...item,
        unitStyle: { ...item.unitStyle },
        roomStyle: { ...item.roomStyle },
        areaStyle: { ...item.areaStyle },
    })),
});

export const cloneRecordAsCopy = (record: SignRecord): SignRecord => {
    const now = new Date().toISOString();
    return {
        ...record,
        id: createId(),
        name: `${record.name} - 副本`,
        showTypes: [...record.showTypes],
        buildingStyle: { ...record.buildingStyle },
        floorStyle: { ...record.floorStyle },
        showInfoLs: record.showInfoLs.map(item => ({
            ...item,
            id: createId(),
            unitStyle: { ...item.unitStyle },
            roomStyle: { ...item.roomStyle },
            areaStyle: { ...item.areaStyle },
        })),
        createdAt: now,
        updatedAt: now,
    };
};

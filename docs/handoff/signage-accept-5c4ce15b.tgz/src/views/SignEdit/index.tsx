import { useMemo, useState } from 'react';

import { Button, Checkbox, Input, InputNumber, Modal, message } from 'antd';

import ColorPicker from '@/components/ColorPicker';
import SignPreview from '@/components/SignPreview';
import WindowShell from '@/components/WindowShell';

import {
    BG_PRESETS,
    HEIGHT_MAX,
    HEIGHT_MIN,
    SHOW_TYPE_OPTIONS,
    STROKE_WIDTH_MAX,
    STROKE_WIDTH_MIN,
    STROKE_WIDTH_STEP,
    THEME_PRIMARY,
    WIDTH_MAX,
    WIDTH_MIN,
} from '@/constants/signage';
import { getRecord, upsertRecord } from '@/services/history';
import type { ShowInfoItem, ShowType, SignDraft, TextStyle } from '@/types/signage';
import { createEmptyRoom, createNewDraft, recordToDraft } from '@/utils/defaults';
import { buildExportDataUrl, downloadPng } from '@/utils/exportPng';
import { clampNumber, normalizeHex } from '@/utils/format';
import { canvasToDataUrl, generateSignCanvas } from '@/utils/generateSignCanvas';
import { createId } from '@/utils/id';

import './index.css';

export type SignEditProps = {
    /** 无 id 则为新建 */
    recordId?: string;
    onBack: () => void;
    onSaved: () => void;
};

type StyleOpenMap = Record<string, boolean>;

const draftSnapshot = (draft: SignDraft) =>
    JSON.stringify({
        name: draft.name,
        width: draft.width,
        height: draft.height,
        borderRadius: draft.borderRadius,
        background: draft.background,
        transparentBackground: draft.transparentBackground,
        buildingNum: draft.buildingNum,
        totalFloorNum: draft.totalFloorNum,
        buildingStyle: draft.buildingStyle,
        floorStyle: draft.floorStyle,
        showTypes: draft.showTypes,
        showInfoLs: draft.showInfoLs,
    });

const toCanvasInput = (draft: SignDraft) => ({
    width: draft.width,
    height: draft.height,
    borderRadius: draft.borderRadius,
    background: draft.background,
    transparentBackground: draft.transparentBackground,
    buildingNum: draft.buildingNum,
    totalFloorNum: draft.totalFloorNum,
    buildingStyle: draft.buildingStyle,
    floorStyle: draft.floorStyle,
    showTypes: draft.showTypes,
    showInfoLs: draft.showInfoLs,
});

function CollapsibleStyleRow({
    title,
    open,
    onToggle,
    style,
    onChange,
}: {
    title: string;
    open: boolean;
    onToggle: () => void;
    style: TextStyle;
    onChange: (patch: Partial<TextStyle>) => void;
}) {
    return (
        <div className='pg-sign-edit__style-row'>
            <button type='button' className='pg-sign-edit__style-toggle' onClick={onToggle}>
                <span>{title}</span>
                <span>{open ? '收起' : '样式'}</span>
            </button>
            {open ? (
                <div className='pg-sign-edit__style-body'>
                    <div className='pg-sign-edit__style-field'>
                        <label>字色</label>
                        <ColorPicker value={style.color} onChange={color => onChange({ color })} />
                    </div>
                    <div className='pg-sign-edit__style-field'>
                        <label>描边色</label>
                        <ColorPicker value={style.strokeColor} onChange={strokeColor => onChange({ strokeColor })} />
                    </div>
                    <div className='pg-sign-edit__style-field'>
                        <label>描边宽</label>
                        <InputNumber
                            min={STROKE_WIDTH_MIN}
                            max={STROKE_WIDTH_MAX}
                            step={STROKE_WIDTH_STEP}
                            value={style.strokeWidth}
                            onChange={v => onChange({ strokeWidth: typeof v === 'number' ? v : 0 })}
                        />
                    </div>
                </div>
            ) : null}
        </div>
    );
}

/**
 * 编辑页：预览 + 表单 IA（记录名→画布→展示类型→楼栋/层→房号）+ 底栏。
 */
function SignEdit({ recordId, onBack, onSaved }: SignEditProps) {
    const [draft, setDraft] = useState<SignDraft>(() => {
        if (recordId) {
            const found = getRecord(recordId);
            if (found) return recordToDraft(found);
        }
        return createNewDraft();
    });
    const [baseline, setBaseline] = useState(() => draftSnapshot(draft));
    const [styleOpen, setStyleOpen] = useState<StyleOpenMap>({});
    const [leaveOpen, setLeaveOpen] = useState(false);
    const [dragFrom, setDragFrom] = useState<number | null>(null);
    const [dragOver, setDragOver] = useState<number | null>(null);
    const [bgMode, setBgMode] = useState<'preset' | 'custom'>(() => {
        const hit = BG_PRESETS.some(p => p.color.toLowerCase() === draft.background.toLowerCase());
        return hit ? 'preset' : 'custom';
    });

    const dirty = useMemo(() => draftSnapshot(draft) !== baseline, [draft, baseline]);

    const patchDraft = (patch: Partial<SignDraft>) => setDraft(prev => ({ ...prev, ...patch }));

    const toggleType = (value: ShowType) => {
        setDraft(prev => {
            const has = prev.showTypes.includes(value);
            const showTypes = has ? prev.showTypes.filter(v => v !== value) : [...prev.showTypes, value];
            return { ...prev, showTypes };
        });
    };

    const updateRoom = (id: string, patch: Partial<ShowInfoItem>) => {
        setDraft(prev => ({
            ...prev,
            showInfoLs: prev.showInfoLs.map(item => (item.id === id ? { ...item, ...patch } : item)),
        }));
    };

    const updateRoomStyle = (id: string, key: 'unitStyle' | 'roomStyle' | 'areaStyle', patch: Partial<TextStyle>) => {
        setDraft(prev => ({
            ...prev,
            showInfoLs: prev.showInfoLs.map(item => (item.id === id ? { ...item, [key]: { ...item[key], ...patch } } : item)),
        }));
    };

    const addRoom = () => setDraft(prev => ({ ...prev, showInfoLs: [...prev.showInfoLs, createEmptyRoom()] }));

    const removeRoom = (id: string) => setDraft(prev => ({ ...prev, showInfoLs: prev.showInfoLs.filter(item => item.id !== id) }));

    const reorderRooms = (from: number, to: number) => {
        if (from === to || from < 0 || to < 0) return;
        setDraft(prev => {
            const next = [...prev.showInfoLs];
            const [moved] = next.splice(from, 1);
            if (!moved) return prev;
            next.splice(to, 0, moved);
            return { ...prev, showInfoLs: next };
        });
    };

    const handleBack = () => {
        if (dirty) {
            setLeaveOpen(true);
            return;
        }
        onBack();
    };

    const handleSave = () => {
        const name = draft.name.trim();
        if (!name) {
            message.warning('请填写记录名称');
            return;
        }
        const now = new Date().toISOString();
        const id = draft.id ?? createId();
        const preview = canvasToDataUrl(generateSignCanvas(toCanvasInput(draft)));
        const existing = draft.id ? getRecord(draft.id) : undefined;
        upsertRecord({
            id,
            name,
            width: draft.width,
            height: draft.height,
            borderRadius: draft.borderRadius,
            background: normalizeHex(draft.background),
            transparentBackground: draft.transparentBackground,
            buildingNum: draft.buildingNum,
            totalFloorNum: draft.totalFloorNum,
            buildingStyle: draft.buildingStyle,
            floorStyle: draft.floorStyle,
            showTypes: draft.showTypes,
            showInfoLs: draft.showInfoLs,
            preview,
            createdAt: existing?.createdAt ?? now,
            updatedAt: now,
        });
        const nextDraft = { ...draft, id, name };
        setDraft(nextDraft);
        setBaseline(draftSnapshot(nextDraft));
        message.success('已保存');
        onSaved();
    };

    const handleExport = () => {
        const dataUrl = buildExportDataUrl(toCanvasInput(draft));
        downloadPng(dataUrl, draft.name.trim() || '标牌');
    };

    const blurClamp = (key: 'width' | 'height', min: number, max: number) => {
        setDraft(prev => ({ ...prev, [key]: clampNumber(prev[key] || min, min, max) }));
    };

    return (
        <WindowShell title={draft.name || '编辑标牌'} showBack onBack={handleBack}>
            <div className='pg-sign-edit'>
                <SignPreview {...toCanvasInput(draft)} />

                <div className='pg-sign-edit__form'>
                    <section className='pg-sign-edit__section'>
                        <h3>基本信息</h3>
                        <label className='pg-sign-edit__label'>记录名称</label>
                        <Input value={draft.name} onChange={e => patchDraft({ name: e.target.value })} />
                    </section>

                    <section className='pg-sign-edit__section'>
                        <h3>标牌画布</h3>
                        <div className='pg-sign-edit__row3'>
                            <div>
                                <label className='pg-sign-edit__label'>宽</label>
                                <InputNumber
                                    className='pg-sign-edit__full'
                                    value={draft.width}
                                    min={WIDTH_MIN}
                                    max={WIDTH_MAX}
                                    onChange={v => patchDraft({ width: typeof v === 'number' ? v : draft.width })}
                                    onBlur={() => blurClamp('width', WIDTH_MIN, WIDTH_MAX)}
                                />
                            </div>
                            <div>
                                <label className='pg-sign-edit__label'>高</label>
                                <InputNumber
                                    className='pg-sign-edit__full'
                                    value={draft.height}
                                    min={HEIGHT_MIN}
                                    max={HEIGHT_MAX}
                                    onChange={v => patchDraft({ height: typeof v === 'number' ? v : draft.height })}
                                    onBlur={() => blurClamp('height', HEIGHT_MIN, HEIGHT_MAX)}
                                />
                            </div>
                            <div>
                                <label className='pg-sign-edit__label'>圆角</label>
                                <InputNumber
                                    className='pg-sign-edit__full'
                                    value={draft.borderRadius}
                                    min={0}
                                    max={999}
                                    onChange={v => patchDraft({ borderRadius: typeof v === 'number' ? v : draft.borderRadius })}
                                />
                            </div>
                        </div>
                        <label className='pg-sign-edit__label'>背景色</label>
                        <div className='pg-sign-edit__bg-presets'>
                            {BG_PRESETS.map(p => {
                                const active = bgMode === 'preset' && draft.background.toLowerCase() === p.color.toLowerCase();
                                return (
                                    <button
                                        key={p.key}
                                        type='button'
                                        className={`pg-sign-edit__chip ${active ? 'is-active' : ''}`}
                                        onClick={() => {
                                            setBgMode('preset');
                                            patchDraft({ background: p.color });
                                        }}
                                    >
                                        <i style={{ background: p.color }} />
                                        {p.label}
                                    </button>
                                );
                            })}
                            <button
                                type='button'
                                className={`pg-sign-edit__chip ${bgMode === 'custom' ? 'is-active' : ''}`}
                                onClick={() => setBgMode('custom')}
                            >
                                自定义
                            </button>
                            {bgMode === 'custom' ? (
                                <ColorPicker value={draft.background} onChange={background => patchDraft({ background })} />
                            ) : null}
                        </div>
                    </section>

                    <section className='pg-sign-edit__section'>
                        <h3>展示类型</h3>
                        <div className='pg-sign-edit__types'>
                            {SHOW_TYPE_OPTIONS.map(opt => {
                                const on = draft.showTypes.includes(opt.value);
                                return (
                                    <button
                                        key={opt.value}
                                        type='button'
                                        className={`pg-sign-edit__type ${on ? 'is-active' : ''}`}
                                        onClick={() => toggleType(opt.value)}
                                    >
                                        {opt.label}
                                    </button>
                                );
                            })}
                        </div>
                    </section>

                    <section className='pg-sign-edit__section'>
                        <h3>标牌基本信息</h3>
                        <p className='pg-sign-edit__hint'>整牌一份（非按房号条）。楼栋号 / 楼层数各自可配字色与描边，样式默认收起。</p>
                        <div className='pg-sign-edit__row2'>
                            <div>
                                <label className='pg-sign-edit__label'>楼栋号</label>
                                <Input
                                    value={draft.buildingNum}
                                    placeholder='如 6'
                                    onChange={e => patchDraft({ buildingNum: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className='pg-sign-edit__label'>楼层数</label>
                                <Input
                                    value={draft.totalFloorNum}
                                    placeholder='如 17'
                                    onChange={e => patchDraft({ totalFloorNum: e.target.value })}
                                />
                            </div>
                        </div>
                        <CollapsibleStyleRow
                            title={`楼栋号「${draft.buildingNum || '—'}#」`}
                            open={Boolean(styleOpen['basic:building'])}
                            onToggle={() => setStyleOpen(m => ({ ...m, 'basic:building': !m['basic:building'] }))}
                            style={draft.buildingStyle}
                            onChange={patch => patchDraft({ buildingStyle: { ...draft.buildingStyle, ...patch } })}
                        />
                        <CollapsibleStyleRow
                            title={`楼层数「${draft.totalFloorNum || '—'}F」`}
                            open={Boolean(styleOpen['basic:floor'])}
                            onToggle={() => setStyleOpen(m => ({ ...m, 'basic:floor': !m['basic:floor'] }))}
                            style={draft.floorStyle}
                            onChange={patch => patchDraft({ floorStyle: { ...draft.floorStyle, ...patch } })}
                        />
                    </section>

                    <section className='pg-sign-edit__section'>
                        <div className='pg-sign-edit__section-head'>
                            <h3>房号信息</h3>
                            {draft.showInfoLs.length > 0 ? (
                                <button type='button' className='pg-sign-edit__link' onClick={addRoom}>
                                    + 添加
                                </button>
                            ) : null}
                        </div>

                        {draft.showInfoLs.length === 0 ? (
                            <div className='pg-sign-edit__rooms-empty'>
                                <div className='pg-sign-edit__rooms-empty-icon'>+</div>
                                <div className='pg-sign-edit__rooms-empty-title'>暂无房号，点击添加</div>
                                <div className='pg-sign-edit__rooms-empty-desc'>
                                    每条含单元号、室号、面积；相邻同单元号在预览第 2 行合并
                                </div>
                                <Button type='primary' onClick={addRoom}>
                                    添加房号
                                </Button>
                            </div>
                        ) : (
                            <div className='pg-sign-edit__rooms'>
                                {draft.showInfoLs.map((room, idx) => (
                                    <div
                                        key={room.id}
                                        className={`pg-sign-edit__room ${dragOver === idx ? 'is-drag-over' : ''}`}
                                        draggable
                                        onDragStart={e => {
                                            setDragFrom(idx);
                                            e.dataTransfer.effectAllowed = 'move';
                                            e.dataTransfer.setData('text/plain', String(idx));
                                        }}
                                        onDragOver={e => {
                                            e.preventDefault();
                                            e.dataTransfer.dropEffect = 'move';
                                            if (dragOver !== idx) setDragOver(idx);
                                        }}
                                        onDragLeave={() => {
                                            if (dragOver === idx) setDragOver(null);
                                        }}
                                        onDrop={e => {
                                            e.preventDefault();
                                            const from = dragFrom ?? Number(e.dataTransfer.getData('text/plain'));
                                            reorderRooms(from, idx);
                                            setDragFrom(null);
                                            setDragOver(null);
                                        }}
                                        onDragEnd={() => {
                                            setDragFrom(null);
                                            setDragOver(null);
                                        }}
                                    >
                                        <div className='pg-sign-edit__room-top'>
                                            <span className='pg-sign-edit__drag' title='拖拽排序'>
                                                ⋮⋮
                                            </span>
                                            <span className='pg-sign-edit__room-index'>#{idx + 1}</span>
                                            <button type='button' className='pg-sign-edit__room-del' onClick={() => removeRoom(room.id)}>
                                                删除
                                            </button>
                                        </div>
                                        <div className='pg-sign-edit__row3'>
                                            <div>
                                                <label className='pg-sign-edit__label'>单元号</label>
                                                <Input
                                                    value={room.unitNum}
                                                    placeholder='如 1'
                                                    onChange={e => updateRoom(room.id, { unitNum: e.target.value })}
                                                />
                                            </div>
                                            <div>
                                                <label className='pg-sign-edit__label'>室号</label>
                                                <Input
                                                    value={room.roomId}
                                                    placeholder='如 1701'
                                                    onChange={e => updateRoom(room.id, { roomId: e.target.value })}
                                                />
                                            </div>
                                            <div>
                                                <label className='pg-sign-edit__label'>面积</label>
                                                <Input
                                                    value={room.area}
                                                    placeholder='如 143'
                                                    onChange={e => updateRoom(room.id, { area: e.target.value })}
                                                    suffix='㎡'
                                                />
                                            </div>
                                        </div>
                                        <CollapsibleStyleRow
                                            title={`单元号「${room.unitNum || '—'}单元」`}
                                            open={Boolean(styleOpen[`${room.id}:unit`])}
                                            onToggle={() => setStyleOpen(m => ({ ...m, [`${room.id}:unit`]: !m[`${room.id}:unit`] }))}
                                            style={room.unitStyle}
                                            onChange={patch => updateRoomStyle(room.id, 'unitStyle', patch)}
                                        />
                                        <CollapsibleStyleRow
                                            title={`室号「${room.roomId || '—'}」`}
                                            open={Boolean(styleOpen[`${room.id}:room`])}
                                            onToggle={() => setStyleOpen(m => ({ ...m, [`${room.id}:room`]: !m[`${room.id}:room`] }))}
                                            style={room.roomStyle}
                                            onChange={patch => updateRoomStyle(room.id, 'roomStyle', patch)}
                                        />
                                        <CollapsibleStyleRow
                                            title={`面积「${room.area || '—'}m²」`}
                                            open={Boolean(styleOpen[`${room.id}:area`])}
                                            onToggle={() => setStyleOpen(m => ({ ...m, [`${room.id}:area`]: !m[`${room.id}:area`] }))}
                                            style={room.areaStyle}
                                            onChange={patch => updateRoomStyle(room.id, 'areaStyle', patch)}
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </section>
                </div>

                <footer className='pg-sign-edit__footer'>
                    <Checkbox checked={draft.transparentBackground} onChange={e => patchDraft({ transparentBackground: e.target.checked })}>
                        透明底
                    </Checkbox>
                    <div className='pg-sign-edit__footer-actions'>
                        <Button onClick={handleBack}>取消</Button>
                        <Button onClick={handleExport}>导出 PNG</Button>
                        <Button type='primary' onClick={handleSave} style={{ boxShadow: `0 4px 12px ${THEME_PRIMARY}40` }}>
                            保存
                        </Button>
                    </div>
                </footer>
            </div>

            <Modal
                open={leaveOpen}
                title='未保存的更改'
                okText='离开'
                cancelText='继续编辑'
                okButtonProps={{ danger: true }}
                onOk={() => {
                    setLeaveOpen(false);
                    onBack();
                }}
                onCancel={() => setLeaveOpen(false)}
                centered
                maskClosable={false}
            >
                当前修改尚未保存，确定离开？
            </Modal>
        </WindowShell>
    );
}

export default SignEdit;

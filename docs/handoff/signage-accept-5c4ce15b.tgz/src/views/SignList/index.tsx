import { useMemo, useState } from 'react';

import { Button, Input, Modal, message } from 'antd';

import WindowShell from '@/components/WindowShell';

import { PAGE_SIZE, THEME_PRIMARY } from '@/constants/signage';
import { listRecords, removeRecord, upsertRecord } from '@/services/history';
import type { SignRecord } from '@/types/signage';
import { cloneRecordAsCopy } from '@/utils/defaults';

import './index.css';

export type SignListProps = {
    onCreate: () => void;
    onEdit: (id: string) => void;
    /** 外部刷新标记 */
    refreshKey?: number;
};

/**
 * 列表页：搜索 + 3 列卡片 + 分页 + 底栏新建；空态引导。
 */
function SignList({ onCreate, onEdit, refreshKey = 0 }: SignListProps) {
    const [query, setQuery] = useState('');
    const [page, setPage] = useState(1);
    const [tick, setTick] = useState(0);
    const [deleting, setDeleting] = useState<SignRecord | null>(null);

    const records = useMemo(() => {
        void refreshKey;
        void tick;
        return listRecords();
    }, [refreshKey, tick]);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        if (!q) return records;
        return records.filter(r => r.name.toLowerCase().includes(q));
    }, [records, query]);

    const total = filtered.length;
    const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const safePage = Math.min(page, pageCount);
    const pageItems = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
    const isEmpty = records.length === 0;

    const handleCopy = (record: SignRecord) => {
        upsertRecord(cloneRecordAsCopy(record));
        setTick(v => v + 1);
        message.success('已复制');
    };

    const handleConfirmDelete = () => {
        if (!deleting) return;
        removeRecord(deleting.id);
        setDeleting(null);
        setTick(v => v + 1);
        message.success('已删除');
    };

    return (
        <WindowShell title='标牌生成器'>
            <div className='pg-sign-list'>
                {!isEmpty ? (
                    <div className='pg-sign-list__search'>
                        <Input
                            allowClear
                            placeholder='搜索记录名'
                            value={query}
                            onChange={e => {
                                setQuery(e.target.value);
                                setPage(1);
                            }}
                        />
                    </div>
                ) : null}

                <main className={`pg-sign-list__main ${isEmpty ? 'is-empty' : ''}`}>
                    {isEmpty ? (
                        <div className='pg-sign-list__empty'>
                            <div className='pg-sign-list__empty-icon'>+</div>
                            <div className='pg-sign-list__empty-title'>还没有标牌</div>
                            <div className='pg-sign-list__empty-desc'>创建第一条，导出 PNG 到本机</div>
                            <Button type='primary' onClick={onCreate}>
                                新建标牌
                            </Button>
                        </div>
                    ) : (
                        <div className='pg-sign-list__grid'>
                            {pageItems.map(item => (
                                <article key={item.id} className='pg-sign-list__card' onClick={() => onEdit(item.id)}>
                                    <div className='pg-sign-list__card-preview'>
                                        {item.preview ? (
                                            <img src={item.preview} alt='' />
                                        ) : (
                                            <div className='pg-sign-list__card-placeholder' />
                                        )}
                                    </div>
                                    <div className='pg-sign-list__card-foot'>
                                        <div className='pg-sign-list__card-name' title={item.name}>
                                            {item.name}
                                        </div>
                                        <div className='pg-sign-list__card-actions' onClick={e => e.stopPropagation()}>
                                            <button type='button' onClick={() => handleCopy(item)}>
                                                复制
                                            </button>
                                            <button type='button' className='is-danger' onClick={() => setDeleting(item)}>
                                                删除
                                            </button>
                                        </div>
                                    </div>
                                </article>
                            ))}
                        </div>
                    )}
                </main>

                {!isEmpty && total > 0 ? (
                    <div className='pg-sign-list__pager'>
                        <span>
                            {safePage}/{pageCount} · 共 {total} 条
                        </span>
                        <div className='pg-sign-list__pager-btns'>
                            <button type='button' disabled={safePage <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>
                                上一页
                            </button>
                            <button type='button' disabled={safePage >= pageCount} onClick={() => setPage(p => Math.min(pageCount, p + 1))}>
                                下一页
                            </button>
                        </div>
                    </div>
                ) : null}

                <footer className='pg-sign-list__footer'>
                    <Button type='primary' onClick={onCreate} style={{ boxShadow: `0 4px 12px ${THEME_PRIMARY}40` }}>
                        新建
                    </Button>
                </footer>
            </div>

            <Modal
                open={Boolean(deleting)}
                title='删除确认'
                okText='删除'
                okButtonProps={{ danger: true }}
                cancelText='取消'
                onOk={handleConfirmDelete}
                onCancel={() => setDeleting(null)}
                centered
            >
                {deleting ? `确定删除「${deleting.name}」？删除后不可恢复。` : null}
            </Modal>
        </WindowShell>
    );
}

export default SignList;
